<?php
add_action( 'widgets_init', 'apr_recent_recipes_init_widget' );

function apr_recent_recipes_init_widget() {
	register_widget( 'Apr_Recent_Recipes' );
}

class Apr_Recent_Recipes extends WP_Widget {
	public function __construct() {
		$widget_ops = array( 'classname' => 'widget_recent_recipe', 'description' => esc_html__( "Your site&#8217;s most recent Recipes.", 'arrowpress-core' ) );
		parent::__construct( 'apr-recent-recipes', esc_html__( 'Apr Recent Recipes', 'arrowpress-core' ), $widget_ops );
		$this->alt_option_name = 'efarm_recent_recipes';
	}

	/**
	 * Outputs the content for the current Recent Recipes widget instance.
	 *
	 * @param array $args     Display arguments including 'before_title', 'after_title',
	 *                        'before_widget', and 'after_widget'.
	 * @param array $instance Settings for the current Recent Recipes widget instance.
	 */
	public function widget( $args, $instance ) {
		if ( ! isset( $args['widget_id'] ) ) {
			$args['widget_id'] = $this->id;
		}

		$title = ( ! empty( $instance['title'] ) ) ? $instance['title'] : '';

		/** This filter is documented in wp-includes/widgets/class-wp-widget-pages.php */
		$title = apply_filters( 'widget_title', $title, $instance, $this->id_base );

		$number = ( ! empty( $instance['number'] ) ) ? absint( $instance['number'] ) : 5;
		if ( ! $number ) {
			$number = 5;
		}
		$show_date = isset( $instance['show_date'] ) ? $instance['show_date'] : false;

		/**
		 * Filter the arguments for the Recent Recipes widget.
		 *
		 * @param array $args An array of arguments used to retrieve the recent posts.
		 *
		 * @see WP_Query::get_posts()
		 *
		 */
		$r = new WP_Query(
			apply_filters( 'widget_posts_args', array(
				'post_type'           => 'recipe',
				'posts_per_page'      => $number,
				'no_found_rows'       => true,
				'post_status'         => 'publish',
				'ignore_sticky_posts' => true
			) )
		);

		if ( $r->have_posts() ) :
			?>
			<?php echo $args['before_widget']; ?>
			<?php if ( $title ) {
			echo $args['before_title'] . $title . $args['after_title'];
		} ?>
			<ul class="blog-content">
				<?php while ( $r->have_posts() ) : $r->the_post(); ?>
					<li class="blog-item">
						<?php if ( has_post_thumbnail() ): ?>
							<?php $blogImages = wp_get_attachment_image_src( get_post_thumbnail_id( get_the_ID() ) );
							if ( ! empty( $blogImages[0] ) ):
								?>
								<div class="blog-img">
									<a class="fancybox-thumb btn-fancybox" data-fancybox-group="fancybox-thumb"
									   href="<?php echo esc_url( $blogImages[0] ); ?>" title="">
										<i class="fa fa-search" aria-hidden="true"></i>
										<img width="98" height="98" src="<?php echo esc_url( $blogImages[0] ); ?>"
											 alt="<?php echo esc_html__( 'recipe', 'arrowpress-core' ) ?>"/>
									</a>
								</div>
							<?php endif; ?>
						<?php endif; ?>
						<div class="blog-post-info">
							<div class="blog-post-title">
								<div class="post-name">
									<a href="<?php the_permalink(); ?>"><?php get_the_title() ? the_title() : the_ID(); ?></a>
								</div>
								<div class="blog-info">
									<?php if ( $show_date ) : ?>
										<div class="info">
											<p><?php echo get_the_date( 'd M, Y' ); ?></p>
										</div>
									<?php endif; ?>
									<?php $count_star = get_post_meta( get_the_ID(), 'star_rating', true );
									$percent_star     = $count_star * 100 / 5;
									?>
									<div class="info review-star">
										<?php echo apr_get_average_ratings( get_the_ID() ); ?>
									</div>
								</div>
							</div>
						</div>
					</li>
				<?php endwhile; ?>
			</ul>
			<?php echo $args['after_widget']; ?>
			<?php
			// Reset the global $the_post as this query will have stomped on it
			wp_reset_postdata();

		endif;
	}

	/**
	 * Handles updating the settings for the current Recent Recipes widget instance.
	 *
	 * @access public
	 *
	 * @param array $new_instance New settings for this instance as input by the user via
	 *                            WP_Widget::form().
	 * @param array $old_instance Old settings for this instance.
	 *
	 * @return array Updated settings to save.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance              = $old_instance;
		$instance['title']     = sanitize_text_field( $new_instance['title'] );
		$instance['number']    = (int) $new_instance['number'];
		$instance['show_date'] = isset( $new_instance['show_date'] ) ? (bool) $new_instance['show_date'] : false;

		return $instance;
	}

	/**
	 * Outputs the settings form for the Recent Recipes widget.
	 *
	 * @access public
	 *
	 * @param array $instance Current settings.
	 */
	public function form( $instance ) {
		$title     = isset( $instance['title'] ) ? esc_attr( $instance['title'] ) : '';
		$number    = isset( $instance['number'] ) ? absint( $instance['number'] ) : 5;
		$show_date = isset( $instance['show_date'] ) ? (bool) $instance['show_date'] : false;
		?>
		<p><label
				for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php echo esc_html__( 'Title:', 'arrowpress-core' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"
				   name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text"
				   value="<?php echo esc_attr( $title ); ?>"/></p>

		<p><label
				for="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>"><?php echo esc_html__( 'Number of posts to show:', 'arrowpress-core' ); ?></label>
			<input class="tiny-text" id="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>"
				   name="<?php echo esc_attr( $this->get_field_name( 'number' ) ); ?>" type="number" step="1" min="1"
				   value="<?php echo esc_attr( $number ); ?>" size="3"/></p>

		<p><input class="checkbox" type="checkbox"<?php checked( $show_date ); ?>
				  id="<?php echo esc_attr( $this->get_field_id( 'show_date' ) ); ?>"
				  name="<?php echo esc_attr( $this->get_field_name( 'show_date' ) ); ?>"/>
			<label
				for="<?php echo esc_attr( $this->get_field_id( 'show_date' ) ); ?>"><?php echo esc_html__( 'Display post date?', 'arrowpress-core' ); ?></label>
		</p>
		<?php
	}
}
